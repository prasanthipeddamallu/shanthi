public class example {
	     int rollno;  
		 String name;  
		 String city;  
		  
         example(int rollno, String name, String city){  
		 this.rollno=rollno;  
		 this.name=name;  
		 this.city=city;  
		 }  
		   
		 public String toString(){ 
		  return rollno+" "+name+" "+city;  
		 }  
		 public static void main(String args[]){  
		   example s1=new example(501,"Rani","lucknow");  
		   example s2=new example(502,"Vasu","hyderabad");  
		     
		   System.out.println(s1);  
		   System.out.println(s2);  
		 }  
		}  


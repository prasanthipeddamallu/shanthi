public class hashwithout {
	  int rollno;  
		 String name;  
		 String city;  
		  
		 hashwithout (int rollno, String name, String city){  
		 this.rollno=rollno;  
		 this.name=name;  
		 this.city=city;  
		 }  
		  
		 public static void main(String args[]){  
			 hashwithout  s1=new  hashwithout (101,"Ravi","Hyderabad");  
			 hashwithout  s2=new  hashwithout (102,"Vamsi","Chennai");  
		     
		   System.out.println(s1);  
		   System.out.println(s2);
		 }  
		}  


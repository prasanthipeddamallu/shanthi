class ByImplementingRunnableInterface  implements Runnable{  
		public void run(){  
		System.out.println("By Implementing thread is running...");  
		}  
		  public static void main(String args[]){  
			ByImplementingRunnableInterface  m1=new ByImplementingRunnableInterface ();  
		Thread t1 =new Thread(m1);  
		t1.start();  
		 }  
		}  


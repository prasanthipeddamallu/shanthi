public class extending extends Thread{  
	public void run(){  
	System.out.println("By Extending thread is running...");  
	}  
	public static void main(String args[]){  
	extending t1=new extending();  
	t1.start();  
	 }  
	}  



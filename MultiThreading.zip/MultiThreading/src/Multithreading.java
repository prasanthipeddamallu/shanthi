public class Multithreading implements Runnable
	{
	       public static void main(String[] args) {
	        Thread MultiThread1 = new Thread("Multi1");
	        Thread MultiThread2 = new Thread("Multi2");
	        MultiThread1.start();
	        MultiThread2.start();
	        System.out.println("Thread names are following:");
	        System.out.println(MultiThread1.getName());
	        System.out.println(MultiThread2.getName());
	    }
	    public void run() {
	    }
	 
	}


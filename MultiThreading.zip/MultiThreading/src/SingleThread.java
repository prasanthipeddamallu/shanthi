
	public class SingleThread
	{
	       public static void main(String[] args) {
	              System.out.println("Single Thread");
	       }
	}


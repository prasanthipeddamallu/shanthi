import java.util.ArrayList;  
	public class equalsexample {
	    public static void main(String[] args) {  
	        String str1 = "Suresh";  
	        ArrayList<String> list = new ArrayList<>();  
	        list.add("Vavi");   
	        list.add("Suresh");  
	        list.add("Mamesh");  
	        list.add("Vijay");  
	        for (String str : list) {  
	            if (str.equals(str1)) {  
	                System.out.println("Suresh is present");  
	            }  
	        }  
	    }  
	}  


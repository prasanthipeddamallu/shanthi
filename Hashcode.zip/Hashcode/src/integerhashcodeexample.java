public class integerhashcodeexample {  
	    public static void main(String[] args)  
	    {  
	        int hashValue = Integer.hashCode(699);  
	        System.out.println("Hash code Value for object is: " + hashValue);  
	    }  
	}  

